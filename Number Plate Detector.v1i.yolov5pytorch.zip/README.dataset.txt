# Number Plate Detector > 2023-03-25 3:15am
https://universe.roboflow.com/my-data/number-plate-detector-quzop

Provided by a Roboflow user
License: CC BY 4.0

